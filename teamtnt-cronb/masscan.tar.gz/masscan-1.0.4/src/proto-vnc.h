#ifndef PROTO_VNC_H
#define PROTO_VNC_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_vnc;


#endif
